package com.company.insightmate.ui.register;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.company.insightmate.R;

public class SignupActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        // Add your register activity logic here
    }
}

