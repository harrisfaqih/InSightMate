package com.company.insightmate.ui.login;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.company.insightmate.R;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Add your login activity logic here
    }
}

